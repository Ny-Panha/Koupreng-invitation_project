from pathlib import Path
import subprocess, json, hashlib, datetime, shutil, sys, time, os, base64
ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args): return subprocess.check_output(['git', *args], cwd=ROOT, text=True, encoding='utf-8').rstrip()
def write(name, data):
    p=OUT/name; p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
if sys.argv[1]=='baseline':
    status=git('status','--porcelain=v1','-uall')
    dirty=[]
    for row in status.splitlines():
        s=row[3:]; p=ROOT/s
        if p.is_file():
            dirty.append({'path':s,'status':row[:2],'sha256':sha(p)})
            dest=OUT/'preimages'/s; dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
    tracked=[]
    for s in git('ls-files').splitlines():
        p=ROOT/s
        if p.is_file(): tracked.append({'path':s,'sha256':sha(p)})
    write('baseline.json',{'timestamp':now(),'branch':git('branch','--show-current'),'head':git('rev-parse','HEAD'),'origin':git('rev-parse','origin/main'),'status':status,'dirty':dirty,'tracked':tracked})
    print('Baseline saved:',len(dirty),'dirty files;',len(tracked),'tracked hashes',flush=True)
elif sys.argv[1] in ['run','run64']:
    label=sys.argv[2]; command=base64.b64decode(sys.argv[3]).decode('utf-8') if sys.argv[1]=='run64' else sys.argv[3]
    if command.endswith(' run build'):
        while (OUT/'frozen-browsers.lock').exists(): time.sleep(0.5)
    start=now(); t=time.monotonic(); command_cwd=ROOT/sys.argv[4] if len(sys.argv)>4 else ROOT
    p=subprocess.run(['powershell','-NoProfile','-Command',command],cwd=command_cwd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    log=OUT/'logs'/f'{label}.log';log.parent.mkdir(exist_ok=True);log.write_bytes(p.stdout)
    if 'test:e2e' in command:
        archive=OUT/'runs'/label;archive.mkdir(parents=True,exist_ok=True)
        sources=[OUT/'browser-results.json'] if '--config playwright.phase11-codex.config.js' in command else [ROOT/'output/playwright/phase11-1/test-results.json'] if '--config playwright.phase11-1.config.js' in command else []
        for source in sources:
            if source.exists(): shutil.copy2(source,archive/source.name)
        if '--config playwright.phase11-codex.config.js' in command and (OUT/'browser-artifacts').exists(): shutil.copytree(OUT/'browser-artifacts',archive/'browser-artifacts',dirs_exist_ok=True)
    frozen=json.loads((OUT/'frozen-source.json').read_text()) if (OUT/'frozen-source.json').exists() else {}
    matches=bool(frozen) and all((ROOT/r['path']).exists() and sha(ROOT/r['path'])==r['sha256'] for r in frozen.get('source',[]))
    rec={'id':label,'command':command,'sourceSHA':frozen.get('sourceSHA') if matches else None,'sourceMatchesFrozenAtEnd':matches,'environment':{key:os.environ.get(key) for key in ['PHASE11_STAGE','VITE_USER_APP_URL','VITE_PUBLIC_APP_URL','VITE_AUTH_STORAGE']},'startedAt':start,'endedAt':now(),'durationSeconds':round(time.monotonic()-t,3),'exitCode':p.returncode,'log':str(log.relative_to(ROOT)).replace('\\','/'),'logSha256':sha(log),'sourceHead':git('rev-parse','HEAD')}
    rec['workingDirectory']=str(command_cwd).replace('\\','/')
    write(f'runs/{label}.json',rec)
    print(json.dumps(rec),flush=True)
    print(p.stdout.decode('utf-8',errors='replace')[-4500:],flush=True)
