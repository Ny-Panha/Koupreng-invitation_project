import { chromium } from "@playwright/test";
import AxeBuilder from "@axe-core/playwright";
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import process from "node:process";
import { Buffer } from 'node:buffer';

const TEST_TOKEN = [
  "eyJhbGciOiJub25lIn0",
  "eyJleHAiOjQxMDIyNjg4MDB9",
  "",
].join(".");

const mockTemplate = {
  id: 30,
  code: "event-essential",
  slug: "event-essential",
  name: "Event Essential",
  category: "MINIMALIST",
  status: "ACTIVE",
  premium: false,
  price: 0,
  currency: "USD",
  thumbnailUrl: "/templates/event-essential.svg",
  supportedEventTypes: ["WEDDING", "ENGAGEMENT", "BIRTHDAY", "ANNIVERSARY", "CORPORATE", "OTHER"],
  supportedLanguages: ["KH", "EN", "BOTH"],
};

const mockCelestial = {
  id: 50,
  code: "khmer-celestial",
  slug: "khmer-celestial",
  name: "Khmer Celestial",
  category: "TRADITIONAL",
  status: "ACTIVE",
  premium: false,
  price: 0,
  currency: "USD",
  thumbnailUrl: "/templates/khmer-celestial.svg",
  supportedEventTypes: ["WEDDING"],
  supportedLanguages: ["KH", "BOTH"],
};

async function establishUserSession(page, { userId = 7, lang = "en", theme = "light" } = {}) {
  await page.addInitScript(({ token, userId, lang, theme }) => {
    const authEnvelope = JSON.stringify({
      accessToken: token,
      tokenType: "Bearer",
      expiresAt: "2100-01-01T00:00:00Z",
      user: { id: userId, fullName: "Audit Host", email: "host@example.test", role: "HOST" },
    });
    window.sessionStorage.setItem("koupreng.auth", authEnvelope);
    window.localStorage.setItem("koupreng.auth", authEnvelope);
    window.localStorage.setItem("koupreng.lang", lang);
    window.localStorage.setItem("theme", theme);
    window.localStorage.setItem("koupreng.colorMode", theme);
  }, { token: TEST_TOKEN, userId, lang, theme });
}

function setupMockApis(page) {
  return page.route("**/api/v1/**", async (route) => {
    const url = new URL(route.request().url());
    const path = url.pathname;
    const method = route.request().method();

    if (path.includes("/templates/recommendations")) {
      return route.fulfill({
        status: 200,
        contentType: "application/json",
        body: JSON.stringify({
          data: [
            { template: mockTemplate, styleMatch: true },
            { template: mockCelestial, styleMatch: false },
          ],
        }),
      });
    }

    if (path === "/api/v1/templates" && method === "GET") {
      return route.fulfill({
        status: 200,
        contentType: "application/json",
        body: JSON.stringify({
          data: [mockTemplate, mockCelestial],
        }),
      });
    }

    if (path.includes("/subscriptions/current")) {
      return route.fulfill({
        status: 200,
        contentType: "application/json",
        body: JSON.stringify({ data: null }),
      });
    }

    if (path.includes("/template-access")) {
      return route.fulfill({
        status: 200,
        contentType: "application/json",
        body: JSON.stringify({ data: { hasAccess: true } }),
      });
    }

    if (path === "/api/v1/invitations" && method === "POST") {
      const body = route.request().postDataJSON();
      return route.fulfill({
        status: 201,
        contentType: "application/json",
        body: JSON.stringify({
          data: {
            id: 888,
            title: body?.title || "Created Event",
            eventType: body?.eventType || "WEDDING",
            visibility: "PRIVATE",
            clientRequestId: body?.clientRequestId,
          },
        }),
      });
    }

    if (path.includes("/cover") && method === "POST") {
      return route.fulfill({
        status: 200,
        contentType: "application/json",
        body: JSON.stringify({
          data: { id: 1, fileUrl: "https://example.com/uploaded-cover.jpg" },
        }),
      });
    }

    return route.fulfill({
      status: 200,
      contentType: "application/json",
      body: JSON.stringify({ data: {} }),
    });
  });
}

const browser=await chromium.launch();const context=await browser.newContext({viewport:{width:393,height:851}});const page=await context.newPage();await establishUserSession(page);await setupMockApis(page);await page.goto('http://127.0.0.1:4315/app/events/new');await page.waitForLoadState('networkidle');const info=await page.locator('.brand-logo img').first().evaluate(el=>({src:el.src,currentSrc:el.currentSrc,complete:el.complete,width:el.naturalWidth}));const response=await page.request.get(info.currentSrc);console.log(JSON.stringify({image:info,status:response.status(),contentType:response.headers()['content-type'],signature:(await response.body()).subarray(0,16).toString('hex')}));await browser.close();