import { chromium } from "@playwright/test";
import AxeBuilder from "@axe-core/playwright";
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import process from "node:process";
import { Buffer } from 'node:buffer';

const TEST_TOKEN = [
  "eyJhbGciOiJub25lIn0",
  "eyJleHAiOjQxMDIyNjg4MDB9",
  "",
].join(".");

const mockTemplate = {
  id: 30,
  code: "event-essential",
  slug: "event-essential",
  name: "Event Essential",
  category: "MINIMALIST",
  status: "ACTIVE",
  premium: false,
  price: 0,
  currency: "USD",
  thumbnailUrl: "/templates/event-essential.svg",
  supportedEventTypes: ["WEDDING", "ENGAGEMENT", "BIRTHDAY", "ANNIVERSARY", "CORPORATE", "OTHER"],
  supportedLanguages: ["KH", "EN", "BOTH"],
};

const mockCelestial = {
  id: 50,
  code: "khmer-celestial",
  slug: "khmer-celestial",
  name: "Khmer Celestial",
  category: "TRADITIONAL",
  status: "ACTIVE",
  premium: false,
  price: 0,
  currency: "USD",
  thumbnailUrl: "/templates/khmer-celestial.svg",
  supportedEventTypes: ["WEDDING"],
  supportedLanguages: ["KH", "BOTH"],
};

async function establishUserSession(page, { userId = 7, lang = "en", theme = "light" } = {}) {
  await page.addInitScript(({ token, userId, lang, theme }) => {
    const authEnvelope = JSON.stringify({
      accessToken: token,
      tokenType: "Bearer",
      expiresAt: "2100-01-01T00:00:00Z",
      user: { id: userId, fullName: "Audit Host", email: "host@example.test", role: "HOST" },
    });
    window.sessionStorage.setItem("koupreng.auth", authEnvelope);
    window.localStorage.setItem("koupreng.auth", authEnvelope);
    window.localStorage.setItem("koupreng.lang", lang);
    window.localStorage.setItem("theme", theme);
    window.localStorage.setItem("koupreng.colorMode", theme);
  }, { token: TEST_TOKEN, userId, lang, theme });
}

function setupMockApis(page) {
  return page.route("**/api/v1/**", async (route) => {
    const url = new URL(route.request().url());
    const path = url.pathname;
    const method = route.request().method();

    if (path.includes("/templates/recommendations")) {
      return route.fulfill({
        status: 200,
        contentType: "application/json",
        body: JSON.stringify({
          data: [
            { template: mockTemplate, styleMatch: true },
            { template: mockCelestial, styleMatch: false },
          ],
        }),
      });
    }

    if (path === "/api/v1/templates" && method === "GET") {
      return route.fulfill({
        status: 200,
        contentType: "application/json",
        body: JSON.stringify({
          data: [mockTemplate, mockCelestial],
        }),
      });
    }

    if (path.includes("/subscriptions/current")) {
      return route.fulfill({
        status: 200,
        contentType: "application/json",
        body: JSON.stringify({ data: null }),
      });
    }

    if (path.includes("/template-access")) {
      return route.fulfill({
        status: 200,
        contentType: "application/json",
        body: JSON.stringify({ data: { hasAccess: true } }),
      });
    }

    if (path === "/api/v1/invitations" && method === "POST") {
      const body = route.request().postDataJSON();
      return route.fulfill({
        status: 201,
        contentType: "application/json",
        body: JSON.stringify({
          data: {
            id: 888,
            title: body?.title || "Created Event",
            eventType: body?.eventType || "WEDDING",
            visibility: "PRIVATE",
            clientRequestId: body?.clientRequestId,
          },
        }),
      });
    }

    if (path.includes("/cover") && method === "POST") {
      return route.fulfill({
        status: 200,
        contentType: "application/json",
        body: JSON.stringify({
          data: { id: 1, fileUrl: "https://example.com/uploaded-cover.jpg" },
        }),
      });
    }

    return route.fulfill({
      status: 200,
      contentType: "application/json",
      body: JSON.stringify({ data: {} }),
    });
  });
}

const output=path.resolve('../../output/playwright/phase11-codex-2026-11-19');
const frozen=JSON.parse(fs.readFileSync(path.join(output,'frozen-source.json'),'utf8'));
const browser=await chromium.launch();const context=await browser.newContext({viewport:{width:1440,height:900},reducedMotion:'reduce'});const page=await context.newPage();
await establishUserSession(page);await setupMockApis(page);
await page.route('**/*',route=>['127.0.0.1','localhost'].includes(new URL(route.request().url()).hostname)?route.fallback():route.abort());
await page.addInitScript(()=>{
  sessionStorage.removeItem('koupreng.onboarding.7');window.__lab={lcp:null,cls:0,inputFrameMs:[]};
  new PerformanceObserver(list=>{for(const e of list.getEntries())window.__lab.lcp=e.startTime;}).observe({type:'largest-contentful-paint',buffered:true});
  new PerformanceObserver(list=>{for(const e of list.getEntries())if(!e.hadRecentInput)window.__lab.cls+=e.value;}).observe({type:'layout-shift',buffered:true});
  document.addEventListener('input',event=>{if(event.target.id!=='event-title')return;const start=performance.now();requestAnimationFrame(()=>window.__lab.inputFrameMs.push(performance.now()-start));},true);
});
const cdp=await context.newCDPSession(page);const rows=[];
for(const condition of ['cold','warm','cpu4x'])for(let index=0;index<(condition==='cpu4x'?3:5);index++){
  await cdp.send('Network.setCacheDisabled',{cacheDisabled:condition!=='warm'});await cdp.send('Emulation.setCPUThrottlingRate',{rate:condition==='cpu4x'?4:1});
  const started=Date.now();await page.goto('http://127.0.0.1:4315/app/events/new');await page.locator('.event-template-card').first().waitFor();await page.evaluate(()=>document.fonts.ready);await page.waitForLoadState('networkidle');
  await page.locator('.event-wizard-step-btn').nth(1).click();await page.locator('#event-title').click();await page.keyboard.type('Fixture');
  await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));
  const data=await page.evaluate(()=>({paint:performance.getEntriesByType('paint').map(p=>({name:p.name,startTime:p.startTime})),...window.__lab,resources:performance.getEntriesByType('resource').filter(r=>['script','css','link','img'].includes(r.initiatorType)).map(r=>({url:new URL(r.name).pathname,initiator:r.initiatorType,duration:r.duration,encodedBodySize:r.encodedBodySize,transferSize:r.transferSize}))}));
  rows.push({condition,index,wallMilliseconds:Date.now()-started,...data});
}
await browser.close();
function percentile(values,q){values=[...values].sort((a,b)=>a-b);return values[Math.max(0,Math.ceil(values.length*q)-1)]??null;}
const summary=['cold','warm','cpu4x'].map(condition=>{const subset=rows.filter(r=>r.condition===condition);const input=subset.flatMap(r=>r.inputFrameMs);return {condition,samples:subset.length,fcpMedianMs:percentile(subset.flatMap(r=>r.paint.filter(p=>p.name==='first-contentful-paint').map(p=>p.startTime)),.5),lcpMedianMs:percentile(subset.map(r=>r.lcp).filter(x=>x!=null),.5),inputFrameMedianMs:percentile(input,.5),inputFrameP95Ms:percentile(input,.95),maximumCLS:Math.max(...subset.map(r=>r.cls)),resourceTransferMedianBytes:percentile(subset.map(r=>r.resources.reduce((sum,x)=>sum+x.transferSize,0)),.5)};});
fs.writeFileSync(path.join(output,'performance-lab.json'),JSON.stringify({status:'COLLECTED — DIAGNOSTIC',sourceSHA:frozen.sourceSHA,buildSHA:frozen.buildSHA,engine:'chromium',viewport:'1440x900',motion:'reduce',timestamp:new Date().toISOString(),rows,summary,limits:['Local intercepted APIs and blocked external resources','13 samples, cold/warm cache and 4x CPU; no field RUM or matched historical latency','Input-to-next-frame proxy is not INP; no thresholds declared or passed','No browser heap/leak or real image-provider measurement']},null,2));
console.log(JSON.stringify(summary));
