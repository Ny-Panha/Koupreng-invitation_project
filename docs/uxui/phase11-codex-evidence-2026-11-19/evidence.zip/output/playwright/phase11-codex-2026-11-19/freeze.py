from pathlib import Path
import json,hashlib,datetime,subprocess
root=Path.cwd();out=root/'output/playwright/phase11-codex-2026-11-19'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def fingerprint(rows):return hashlib.sha256(json.dumps(rows,sort_keys=True,separators=(',',':')).encode()).hexdigest()
source=[]
for app in ['frontend-user','frontend-admin']:
 for p in (root/'apps'/app/'src').rglob('*'):
  if p.is_file() and p.suffix in ['.js','.jsx','.css','.json'] and not '.test.' in p.name:
   source.append({'path':str(p.relative_to(root)).replace('\\','/'),'sha256':sha(p)})
 for p in (root/'apps'/app).glob('*'):
  if p.is_file() and (p.name.startswith(('package','vite.config','playwright.phase11-codex'))):source.append({'path':str(p.relative_to(root)).replace('\\','/'),'sha256':sha(p)})
source.sort(key=lambda r:r['path']);build=[]
for p in (root/'apps/frontend-user/dist').rglob('*'):
 if p.is_file():build.append({'path':str(p.relative_to(root/'apps/frontend-user/dist')).replace('\\','/'),'sha256':sha(p),'bytes':p.stat().st_size})
build.sort(key=lambda r:r['path'])
record={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceSHA':fingerprint(source),'buildSHA':fingerprint(build),'source':source,'build':build}
(out/'frozen-source.json').write_text(json.dumps(record,indent=2),encoding='utf-8');print(record['sourceSHA'],record['buildSHA'])
