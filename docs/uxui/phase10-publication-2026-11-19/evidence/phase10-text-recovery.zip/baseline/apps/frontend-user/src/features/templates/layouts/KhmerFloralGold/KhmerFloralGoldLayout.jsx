import { Children, cloneElement, isValidElement, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { ArrowLeft, CalendarDays, ChevronDown, Globe2, MapPin, Music2, Pause, X } from 'lucide-react';
import { usePrefersReducedMotion } from '@/shared/hooks/usePrefersReducedMotion';
import Modal from '@/shared/ui/Modal';
import { isTrustedPreviewMessage, postPreviewMessage, readEmbeddedPreviewChannel } from '@/shared/preview/previewMessaging';
import { InvitationLocaleContext } from '../../shared/invitationLocaleContext';
import { normalizeTemplateViewModel } from '../../model/templateModel';
import FamilyNames from '../../shared/FamilyNames';
import InvitationBranding from '../../shared/InvitationBranding';
import ProgramTimeline from '../../shared/ProgramTimeline';
import FloralProgramTimeline from './FloralProgramTimeline';
import { EventCalendar, WeddingCountdown, AddToCalendar } from '../../shared/SaveTheDate';
import { formatEventDate, formatEventTime, formatNumerals, resolveEvent } from '../../shared/eventDateTime';
import { visibleProgramDays } from '../../shared/program';
import { safeDirections } from '../../shared/invitationFeatures';
import { safeIntroMedia } from '../../shared/cinematicIntro';
import { useCinematicOpening, useCinematicPlayback } from '../../shared/Openings/cinematicOpeningContext';
import { invitationStyles } from '../../shared/invitationStyles';
import DatePresentation from '../../shared/DatePresentation';
import CoverBackground from '../../shared/Openings/CoverBackground';
import GuestSectionNavigation from '../../shared/Controls/GuestSectionNavigation';
import { useTemplateMusicController } from '../../experience/hooks/useTemplateMusicController';
import { floralColor, floralContent, floralInitials, floralMonogramText, floralMusic, floralLocales, floralPhotos, floralSections } from './floralModel';
import { FloralArchedHeading, FloralDivider, FloralMonogram, FloralPhoto, GoldFlourish, GoldPlaque } from './FloralArtwork';
import FloralGallery from './FloralGallery';
import FloralAmbience, { FloralSceneCorners, FloralSceneBackdrop } from './FloralAmbience';
import useFloralEnvironment from './useFloralEnvironment';
import useFloralScrollReveal from './useFloralScrollReveal';
import useFloralMotion from './useFloralMotion';
import useFloralCoverTypography from './useFloralCoverTypography';
import './khmer-floral-gold.css';

function DemoRsvp({ english }) {
  const [response, setResponse] = useState('ATTENDING');
  const [message, setMessage] = useState('');
  return <form className="kfg-demo-rsvp" onSubmit={event => { event.preventDefault(); setMessage(english ? 'Preview only. Your response was not sent.' : 'នេះជាគំរូប៉ុណ្ណោះ។ ការឆ្លើយតបរបស់អ្នកមិនត្រូវបានផ្ញើទេ។'); }}>
    <p className="kfg-muted">{english ? 'Try this demonstration form. Responses are not saved.' : 'សាកល្បងទម្រង់គំរូនេះ។ ការឆ្លើយតបមិនត្រូវបានរក្សាទុកទេ។'}</p>
    <fieldset><legend>{english ? 'Will you attend?' : 'តើអ្នកអាចចូលរួមបានទេ?'}</legend><div className="kfg-attendance">{[['ATTENDING', 'ចូលរួម', 'Attending'], ['DECLINED', 'មិនចូលរួម', 'Not attending']].map(([value, km, en]) => <label key={value}><input type="radio" name="attendance" value={value} checked={response === value} onChange={() => setResponse(value)} /><span>{english ? en : km}</span></label>)}</div></fieldset>
    <label>{english ? 'Guest name' : 'ឈ្មោះភ្ញៀវ'}<input name="guestName" required maxLength={120} autoComplete="name" /></label>
    <button className="kfg-gold-button" type="submit">{english ? 'Try RSVP' : 'សាកល្បងឆ្លើយតប'}</button>
    {message && <p role="status">{message}</p>}
  </form>;
}

export default function KhmerFloralGoldLayout({ content = {}, liveData, preview = false, previewStartClosed = false,
  previewChannel, previewGateCommand, isHostedInvitation = false, showBack = true, backTo = '/templates', useTemplateLink, showActions = true, children }) {
  const [params, setParams] = useSearchParams();
  const raw = useMemo(() => normalizeTemplateViewModel({}, { ...content, ...liveData,
    ...(liveData ? { localizedContentV1: liveData.localizedContentV1 || null } : {}),
    ...(liveData?.groomName !== undefined ? { groom: liveData.groomName } : {}),
    ...(liveData?.brideName !== undefined ? { bride: liveData.brideName } : {}),
    ...(liveData?.photos !== undefined ? { gallery: liveData.photos } : {}),
    ...(liveData?.musicUrl !== undefined ? { music: liveData.musicUrl } : {}),
  }), [content, liveData]);
  const hosted = isHostedInvitation || raw.hasHostContent || Boolean(liveData);
  const locales = floralLocales(raw, hosted);
  const [choice, setChoice] = useState(null);
  const wanted = choice?.source === raw.languageMode ? choice.value : params.get('lang') || (String(raw.languageMode).toLowerCase() === 'en' ? 'en' : 'km');
  const locale = locales.includes(wanted) ? wanted : locales[0];
  const vm = floralContent(raw, locale);
  const en = locale === 'en', t = (km, english) => en ? english : km;

  const [phase, setPhase] = useState(preview && !previewStartClosed ? 'content' : 'closed');
  const opened = phase === 'content';
  const style = invitationStyles({ ...vm, code: 'khmer-floral-gold' }), palette = vm.studioStyle || {};
  const welcomeDuration = style.welcomeSeconds * 1000;
  const guestName = vm.isPersonalizedGuest ? vm.guestName : t(style.genericGuestNameKm, style.genericGuestNameEn);
  const openLabel = t(style.openButtonLabelKm, style.openButtonLabelEn);
  const salutationKey = en ? 'guestSalutationEn' : 'guestSalutationKm';
  const salutation = Object.hasOwn(vm.invitationStyleV1 || {}, salutationKey) ? style[salutationKey] : vm.subtitle || style[salutationKey];
  const motionPreset = String(vm.invitationStyleV1?.motion ? style.motion : palette.motion === 'minimal' ? 'none' : palette.motion || style.motion);
  const openRef = useRef(opened), bodyRef = useRef(null), rootRef = useRef(null);
  const openingTimer = useRef(null), welcomeRef = useRef(null);
  const startCinematic = useCinematicOpening();
  const playback = useCinematicPlayback();
  const [mapOpen, setMapOpen] = useState(false);
  const [galleryOpen, setGalleryOpen] = useState(false);
  const reduced = usePrefersReducedMotion();
  const environment = useFloralEnvironment();
  useFloralCoverTypography(rootRef,phase,vm.title,guestName,style.headingSize,style.guestTextSize);
  useFloralScrollReveal(rootRef, opened && !reduced && !environment.saveData && motionPreset !== 'none');
  useFloralMotion(rootRef, phase, !reduced && !environment.saveData && !environment.slow && !environment.hidden && motionPreset !== 'none', motionPreset);
  const event = resolveEvent(vm), numerals = vm.saveTheDate?.numerals || (en ? 'latin' : 'khmer');
  const days = visibleProgramDays(vm);
  const programContent = { ...vm, invitationStyleV1: { program: 'gold-curve', ...vm.invitationStyleV1 } };
  const Timeline = programContent.invitationStyleV1.program === 'gold-curve' ? FloralProgramTimeline : ProgramTimeline;
  const photos = floralPhotos(vm, en);
  const musicSource = floralMusic(liveData ? { ...liveData, enabledSections: raw.enabledSections } : raw);
  const [audioRef, music] = useTemplateMusicController(musicSource);
  const { play, pause } = music;
  const channel = useMemo(() => previewChannel || readEmbeddedPreviewChannel(), [previewChannel]);
  const open = useCallback((gesture = false) => {
    if (gesture && openRef.current) return;
    openRef.current = true;
    const duration = gesture && !reduced && !environment.saveData && motionPreset !== 'none' ? ({ subtle: 350, romantic: 1000, elegant: 800, cinematic: 1300 })[motionPreset] : 0;
    setPhase(duration ? 'opening' : 'content');
    if (gesture && musicSource) void play();
    clearTimeout(openingTimer.current);
    if (duration) openingTimer.current = window.setTimeout(() => { setPhase('welcome'); }, duration);
    else { if (gesture) startCinematic(); requestAnimationFrame(() => bodyRef.current?.focus({ preventScroll: true })); }
  }, [play, musicSource, reduced, environment.saveData, motionPreset, startCinematic]);
  const skipOpening = () => { clearTimeout(openingTimer.current); playback.stop(); setPhase('content'); requestAnimationFrame(() => bodyRef.current?.focus({ preventScroll: true })); };
  useEffect(() => () => clearTimeout(openingTimer.current), []);
  useEffect(() => {
    if (phase !== 'welcome' || preview) return;
    requestAnimationFrame(() => welcomeRef.current?.focus({ preventScroll: true }));
    const timer = window.setTimeout(() => { setPhase('content'); startCinematic(); requestAnimationFrame(() => bodyRef.current?.focus({ preventScroll: true })); }, welcomeDuration);
    return () => window.clearTimeout(timer);
  }, [phase, preview, startCinematic, welcomeDuration]);

  useEffect(() => {
    if (!previewGateCommand) return;
    clearTimeout(openingTimer.current);
    openRef.current = Boolean(previewGateCommand.open); setPhase(openRef.current ? 'content' : 'closed');
    if (!openRef.current) pause();
  }, [previewGateCommand, pause]);
  useEffect(() => {
    if (!channel) return;
    postPreviewMessage({ type: 'PREVIEW_READY' }, channel);
    const message = event => {
      if (!isTrustedPreviewMessage(event, channel) || event.data.type !== 'SCROLL_TO_SECTION') return;
      const key = ({ venue: 'map', calendar: 'invitation', cover: 'family' })[event.data.sectionKey] || event.data.sectionKey;
      if (key === 'invitation') { clearTimeout(openingTimer.current); openRef.current = true; setPhase('welcome'); return; }
      open(); requestAnimationFrame(() => rootRef.current?.querySelector(`[data-section-key="${CSS.escape(key || '')}"]`)?.scrollIntoView({ behavior: 'auto', block: 'start' }));
    };
    window.addEventListener('message', message); return () => window.removeEventListener('message', message);
  }, [channel, open]);
  const language = value => {
    setChoice({ source: raw.languageMode, value });
    if (!preview) { const next = new URLSearchParams(params); next.set('lang', value); setParams(next, { replace: true, preventScrollReset: true }); }
  };
  const venue = vm.venueName || vm.venue?.name || '', address = vm.venueAddress || vm.venue?.address || '';
  const directions = safeDirections(vm.googleMapUrl || vm.googleMapsUrl || vm.venue?.mapLink);
  const couplePhoto = safeIntroMedia(vm.backgroundImage || vm.coverImage);
  const navigationKeys = floralSections(vm).filter(key => ({
    family: Boolean(vm.groom || vm.bride || vm.invitationImage || vm.invitationImage2),
    invitation: event.validDate && vm.saveTheDate?.enabled !== false && vm.saveTheDate?.showCalendar !== false,
    countdown: event.validDate, map: Boolean(venue || address || directions || vm.sketchMapImage),
    gallery: photos.length > 0, schedule: days.length > 0, rsvp: Boolean(children) || !hosted,
  })[key]).join(',');
  const headings = {
    invitation: t('សិរីមង្គលអាពាហ៍ពិពាហ៍', 'You are warmly invited'), family: t(style.familyHeadingKm, style.familyHeadingEn),
    countdown: t('រាប់ថយក្រោយដល់ថ្ងៃមង្គល', 'Until our celebration'), schedule: t('របៀបវារៈកម្មវិធី', 'Wedding agenda'),
    map: t('ទីតាំងប្រារព្ធពិធី', 'Event location'), gallery: t('កម្រងរូបអនុស្សាវរីយ៍', 'Our photographs'), rsvp: t('សូមឆ្លើយតបការអញ្ជើញ', 'Will you join us?'),
  };
  const renderSection = key => {
    switch (key) {
      case 'invitation': return <><h2>{headings.invitation}</h2><FloralDivider /><p className="kfg-welcome">{vm.messageTitle || t('សូមគោរពអញ្ជើញ', 'With great joy')}</p><p className="kfg-welcome-copy">{vm.messageText}</p>{event.validDate ? (vm.saveTheDate?.enabled !== false && vm.saveTheDate?.showCalendar !== false && <DatePresentation content={vm} english={en} calendar={<EventCalendar date={event.date} english={en} numerals={numerals} navigation={vm.saveTheDate?.calendarNavigation} />} />) : <p className="kfg-muted">{t('កាលបរិច្ឆេទនឹងត្រូវបានបញ្ជាក់។', 'The date will be confirmed.')}</p>}</>;
      case 'family': return <><h2>{headings.family}</h2><p className="kfg-honored-guest"><span>{guestName}</span></p><FloralDivider /><FamilyNames content={{ ...vm, coupleMonogram: null }} /><p className="kfg-family-intro">{t(style.familyIntroKm, style.familyIntroEn)}</p><div className="kfg-portraits"><figure className="kfg-groom"><FloralPhoto src={vm.invitationImage} alt={vm.groom || t('រូបកូនកំលោះ', 'Groom portrait')} /><figcaption><span>{t('កូនកំលោះ', 'The groom')}</span><strong>{vm.groom}</strong></figcaption></figure><figure className="kfg-bride"><FloralPhoto src={vm.invitationImage2} alt={vm.bride || t('រូបកូនក្រមុំ', 'Bride portrait')} /><figcaption><span>{t('កូនក្រមុំ', 'The bride')}</span><strong>{vm.bride}</strong></figcaption></figure></div>{event.validDate && vm.saveTheDate?.enabled !== false && (vm.invitationStyleV1?.date || vm.saveTheDate?.showCalendar === true ? <DatePresentation content={vm} english={en} calendar={<EventCalendar date={event.date} english={en} numerals={numerals} navigation={vm.saveTheDate?.calendarNavigation} />} /> : <div className="kfg-date-card"><span>{formatEventDate(event.date, en, numerals, { day: undefined, year: undefined })}</span><strong>{formatNumerals(Number(event.date.slice(-2)), numerals)}</strong><span>{formatEventDate(event.date, en, numerals, { weekday: 'long', month: undefined, year: undefined, day: undefined })}</span><small>{formatEventTime(event.time, en, numerals)}</small></div>)}</>;
      case 'couplePhoto': return <div className="kfg-couple-photograph"><FloralPhoto src={couplePhoto} alt={t('រូបគូស្នេហ៍', 'Wedding couple portrait')} /></div>;
      case 'countdown': return <><h2>{vm.saveTheDate?.heading || headings.countdown}</h2>{vm.saveTheDate?.subtitle && <p>{vm.saveTheDate.subtitle}</p>}{vm.saveTheDate?.showCountdown === false ? null : event.instant !== null ? <WeddingCountdown instant={event.instant} english={en} numerals={numerals} /> : <p className="kfg-muted">{t('ម៉ោងកម្មវិធីនឹងត្រូវបានបញ្ជាក់។', 'The event time will be confirmed.')}</p>}{event.validDate && vm.saveTheDate?.showAddToCalendar !== false && <div className="kfg-calendar-action"><GoldPlaque /><AddToCalendar content={vm} english={en} /></div>}</>;
      case 'schedule': return <><h2>{headings.schedule}</h2>{programContent.invitationStyleV1.program !== 'gold-curve' && <FloralDivider />}{days.length ? <Timeline content={programContent} english={en} days={days} naturalTime /> : <p className="kfg-muted">{t('កម្មវិធីលម្អិតនឹងត្រូវបានបញ្ជាក់។', 'The program will be announced soon.')}</p>}</>;
      case 'map': return <><h2>{headings.map}</h2><p className="kfg-venue-name">{venue || t('ទីតាំងនឹងត្រូវបានបញ្ជាក់។', 'Venue to be confirmed.')}</p>{address && <p>{address}</p>}{vm.sketchMapImage && <figure className="kfg-map"><button type="button" onClick={() => setMapOpen(true)} aria-label={t('មើលផែនទីធំ', 'View larger venue map')}><FloralPhoto src={vm.sketchMapImage} alt={t('គំនូសប្លង់ទីតាំងកម្មវិធី', 'Illustrative venue diagram')} /></button><figcaption>{t('គំនូសប្លង់ទីតាំងកម្មវិធី', 'Illustrative venue diagram')}</figcaption></figure>}{directions && <a className="kfg-gold-button kfg-map-directions" href={directions} target="_blank" rel="noopener noreferrer"><GoldPlaque /><span>{t('មើលទីតាំងក្នុង Google Maps', 'View in Google Maps')}</span></a>}</>;
      case 'gallery': return <><h2>{headings.gallery}</h2><FloralDivider /><FloralGallery photos={photos} english={en} layout={style.gallery} motion={environment.saveData ? 'none' : motionPreset} onExpandedChange={setGalleryOpen} /></>;
      case 'closing': return <><h2>{vm.thankYouTitle || t('សូមថ្លែងអំណរគុណ', 'With our sincere thanks')}</h2><p>{vm.thankYouText || t('វត្តមានរបស់លោកអ្នក គឺជាកិត្តិយសសម្រាប់យើងខ្ញុំ។', 'Your presence would be an honor to us.')}</p>{vm.apologyText && <div className="kfg-apology"><FloralDivider /><h3>{vm.apologyTitle || t('លិខិតសូមអភ័យទោស', 'A personal invitation')}</h3><p>{vm.apologyText}</p></div>}</>;
      case 'rsvp': return <><h2>{headings.rsvp}</h2><FloralDivider />{children ? Children.map(children, child => isValidElement(child) ? cloneElement(child, { languageMode: en ? 'EN' : 'KH', appearance: 'floral' }) : child) : hosted ? <p className="kfg-muted">{t('សូមទាក់ទងម្ចាស់កម្មវិធី ដើម្បីបញ្ជាក់ការចូលរួម។', 'Please contact your hosts to confirm your attendance.')}</p> : <DemoRsvp english={en} />}</>;
      default: return null;
    }
  };
  return <InvitationLocaleContext value={locale}><div ref={rootRef} className={`kfg-invitation${preview ? ' kfg-preview' : ''}${opened ? ' is-open' : ''}${phase === 'opening' ? ' is-opening' : ''}`} lang={locale} data-template-renderer="khmer-floral-gold" data-reduced-motion={reduced} data-motion={motionPreset} data-low-power={environment.saveData} data-page-hidden={environment.hidden} data-florals={style.florals} data-portrait-frame={style.portraitFrame} data-map-style={style.map}
    style={{ '--kfg-welcome-duration': `${welcomeDuration}ms`, '--kfg-open-padding': `${style.openButtonPadding}px`, '--kfg-open-text-size': `${style.openButtonTextSize}px`, '--kfg-guest-text-size': `${style.guestTextSize}px`, '--kfg-gold': floralColor(palette.primary || palette.accent || vm.frontColor || vm.primaryColor), '--kfg-paper': floralColor(palette.background || vm.backgroundColor), '--kfg-ink': floralColor(palette.text), '--kfg-highlight': floralColor(palette.accent || palette.border), '--kfg-frame-color': floralColor(palette.border), '--kfg-body': palette.bodyFont ? `${JSON.stringify(palette.bodyFont)}, KfgBody, sans-serif` : undefined, '--kfg-message-align': ['left', 'center', 'right'].includes(palette.align) ? palette.align : undefined, '--kfg-message-scale': ({ small: .9, normal: 1, large: 1.12 })[palette.messageSize] || 1, '--kfg-portrait-y': `${palette.portraitY ?? 50}%`, '--kfg-heading-font': vm.fontKhmer ? `${JSON.stringify(vm.fontKhmer)}, var(--kfg-display)` : undefined, '--kfg-latin-font': vm.fontLatin ? `${JSON.stringify(vm.fontLatin)}, serif` : undefined }}>
    <div className="kfg-paper-art" aria-hidden="true" />{(opened || phase === 'welcome') && <FloralSceneBackdrop enabled={style.florals && style.sceneBackground && !environment.saveData} />}<FloralAmbience enabled={style.florals && !reduced && !environment.saveData && !environment.slow && motionPreset !== 'none'} paused={environment.hidden} motion={motionPreset} petalCount={style.petalCount} butterflyCount={style.butterflyCount} />
    {wanted === 'en' && !locales.includes('en') && <p className="kfg-locale-notice" role="status" lang="en">English is not published for this invitation. Showing Khmer.</p>}
    <div className="kfg-toolbar"><label className="kfg-language"><Globe2 size={16} aria-hidden="true" /><span className="kfg-sr-only">{t('ភាសាធៀប', 'Invitation language')}</span><select value={locale} onChange={event => language(event.target.value)}>{locales.includes('km') && <option value="km">ខ្មែរ</option>}{locales.includes('en') && <option value="en">English</option>}</select><ChevronDown size={14} aria-hidden="true" /></label>
      <div className="kfg-toolbar-actions">{phase === 'welcome' && <button type="button" className="kfg-skip-welcome" aria-label={t('រំលង', 'Skip introduction')} onClick={skipOpening}>{t('រំលង', 'Skip')}</button>}
      {musicSource && <button type="button" className="kfg-music" onClick={music.toggle} data-music-status={music.status} aria-pressed={music.playing} aria-label={music.playing ? t('ផ្អាកភ្លេង', 'Pause music') : t('ចាក់ភ្លេង', 'Play music')}>{music.playing ? <Pause size={18} aria-hidden="true" /> : <Music2 size={18} aria-hidden="true" />}</button>}</div></div>
    {musicSource && <audio ref={audioRef} src={musicSource} loop preload="none" />}{music.status === 'error' && <p className="kfg-audio-error" role="status">{t('មិនអាចចាក់ភ្លេងបានទេ។ សូមចុចរូបតន្ត្រីដើម្បីសាកម្ដងទៀត។', 'Music could not play. Use the music button to try again.')}</p>}
    {phase === 'welcome' ? <section ref={welcomeRef} tabIndex={-1} className="kfg-welcome-scene" data-section-key="invitation" aria-label={t('សារអញ្ជើញ', 'Invitation welcome')}>
      <FloralSceneCorners enabled={style.florals && style.sceneBranches} />{renderSection('invitation')}
      {style.showWelcomeContinue && <button className="kfg-continue" type="button" onClick={skipOpening}>{t('បន្តទៅព័ត៌មានមង្គលការ', 'Continue to wedding details')}</button>}
    </section> : !opened ? <section className="kfg-opening" aria-label={t('សំបុត្រអញ្ជើញ', 'Wedding invitation cover')}>
      <div className="kfg-cover-background" aria-hidden="true" style={{ '--kfg-cover-fit': style.backgroundFit, '--kfg-cover-position': `${style.backgroundX}% ${style.backgroundY}%`, filter: `blur(${style.backgroundBlur}px)`, opacity: 1 - style.backgroundOverlay }}><CoverBackground content={{ coverBackgroundImage: safeIntroMedia(vm.coverBackgroundImage), openingVideoUrl: vm.openingVideoEnabled === false ? '' : safeIntroMedia(vm.openingVideoUrl || vm.videoUrl || vm.openingVideo?.url || vm.openingVideo), videoPoster: safeIntroMedia(vm.videoPoster) }} /></div>
      {style.florals && style.sideFlorals && <><img className="kfg-cover-side kfg-cover-side--left" src="/templates/khmer-floral-gold/effects/realistic/white-green-border-top.webp" width="1536" height="512" alt="" aria-hidden="true" draggable={false} /><img className="kfg-cover-side kfg-cover-side--right" src="/templates/khmer-floral-gold/effects/realistic/white-green-border-bottom.webp" width="1536" height="512" alt="" aria-hidden="true" draggable={false} /><img className="kfg-cover-side kfg-cover-side--lower kfg-cover-side--left" src="/templates/khmer-floral-gold/effects/realistic/white-green-border-bottom.webp" width="1536" height="512" alt="" aria-hidden="true" draggable={false} /><img className="kfg-cover-side kfg-cover-side--lower kfg-cover-side--right" src="/templates/khmer-floral-gold/effects/realistic/white-green-border-top.webp" width="1536" height="512" alt="" aria-hidden="true" draggable={false} /></>}
      <h1 aria-label={vm.title || t('សិរីមង្គលអាពាហ៍ពិពាហ៍', 'Wedding invitation')} style={{ fontSize: `min(${style.headingSize}px,calc(var(--kfg-cover-safe-width) * .086),var(--kfg-cover-heading-limit,40px))`, textAlign: style.headingAlign, '--kfg-heading-justify': ({left:'flex-start',center:'center',right:'flex-end'})[style.headingAlign] }}>{style.headingMode === 'image' && style.headingImage ? <FloralPhoto className="kfg-heading-art" src={style.headingImage} alt={vm.title || t('សិរីមង្គលអាពាហ៍ពិពាហ៍', 'Wedding invitation')} priority /> : style.headingShape === 'arched' ? <FloralArchedHeading text={vm.title || t('សិរីមង្គលអាពាហ៍ពិពាហ៍', 'Wedding invitation')} /> : vm.title || t('សិរីមង្គលអាពាហ៍ពិពាហ៍', 'Wedding invitation')}</h1>
      <div className="kfg-cover-emblem">
      {style.monogram === 'regal-scroll-gold' ? <FloralMonogram text={floralMonogramText(vm, style.monogramMode)} variant={style.monogram} settings={style}>{style.monogramMode === 'image' && style.monogramImage ? <FloralPhoto className="kfg-monogram-logo" src={style.monogramImage} alt={floralInitials(vm) || t('រូបតំណាងគូស្វាមីភរិយា', 'Couple logo')} priority /> : null}</FloralMonogram> : style.monogramMode === 'image' && style.monogramImage ? <FloralPhoto className="kfg-monogram-logo" src={style.monogramImage} alt={floralInitials(vm) || t('រូបតំណាងគូស្វាមីភរិយា', 'Couple logo')} priority /> : <FloralMonogram text={floralMonogramText(vm, style.monogramMode)} variant={style.monogram} settings={style} />}
      </div>
      <div className="kfg-guest"><p>{salutation}</p><div className={`kfg-guest-frame kfg-guest-frame--${style.guestFrame}`}>
        {style.guestFrame !== 'khmer' && <GoldFlourish />}
        <span>{guestName}</span>
        {style.guestFrame !== 'khmer' && <GoldFlourish className="kfg-flourish-bottom" />}
      </div></div>
      <div className="kfg-cover-details" hidden={!(style.showCoverDate && event.validDate) && !(style.showCoverVenue && (venue || address))}>
        {style.showCoverDate && event.validDate && <p><CalendarDays size={15} aria-hidden="true" /><time dateTime={event.date}>{formatEventDate(event.date,en,numerals,{weekday:'long'})}</time></p>}
        {style.showCoverVenue && (venue || address) && <address><MapPin size={15} aria-hidden="true" /><span>{venue && <span>{venue}</span>}{address && address !== venue && <span>{address}</span>}</span></address>}
      </div>
      <button type="button" className="kfg-gold-button kfg-open" aria-label={openLabel} aria-description={t('បើកសំបុត្រអញ្ជើញ', 'Open the wedding invitation')} disabled={phase === 'opening'} onClick={() => open(true)}><span>{openLabel}</span></button>
      {phase === 'opening' && <button className="kfg-skip-opening" type="button" onClick={skipOpening}>{t('រំលង', 'Skip opening')}</button>}</section>
      : <main ref={bodyRef} className="kfg-content" tabIndex={-1} aria-label={t('ព័ត៌មានអាពាហ៍ពិពាហ៍', 'Wedding details')}><FloralSceneCorners enabled={style.florals && style.sceneBranches} /><h1 className="kfg-sr-only">{vm.title || t('សិរីមង្គលអាពាហ៍ពិពាហ៍', 'Wedding invitation')}</h1>{floralSections(vm).filter(key => key !== 'invitation').map(key => <section key={key} className={`kfg-section kfg-${key}`} data-section-key={key} data-tx-section={key === 'map' ? 'venue' : key}>{renderSection(key)}</section>)}<footer className="kfg-footer"><FloralDivider /><span>{vm.groom} &amp; {vm.bride}</span><InvitationBranding content={vm} language={en ? 'en' : 'km'} />{!hosted && <small>{t('រូបភាពសម្រាប់គំរូបង្ហាញ៖ Jin Wedding / Pexels', 'Demo stock models and photography: Jin Wedding / Pexels')}</small>}</footer></main>}
    {!hosted && showActions && <div className="kfg-demo-actions">{showBack && <Link to={backTo}><ArrowLeft size={16} aria-hidden="true" />{t('ត្រឡប់ទៅគំរូ', 'Back to templates')}</Link>}{useTemplateLink && <Link to={useTemplateLink}>{t('ប្រើគំរូឥតគិតថ្លៃនេះ', 'Use this free template')}</Link>}</div>}
    <Modal isOpen={mapOpen} onClose={() => setMapOpen(false)} showHeader={false} size="lg" className="kfg-map-dialog" ariaLabel={t('គំនូសប្លង់ទីតាំង', 'Venue diagram')}><button type="button" className="kfg-map-close" onClick={() => setMapOpen(false)} aria-label={t('បិទផែនទី', 'Close map')}><X aria-hidden="true" /></button><FloralPhoto src={vm.sketchMapImage} alt={t('គំនូសប្លង់ទីតាំងកម្មវិធី', 'Illustrative venue diagram')} /></Modal>
    {opened && playback.completed && <button type="button" className="kfg-replay-video" onClick={() => startCinematic(undefined, 0, { replay: true })}>{t('ចាក់វីដេអូម្ដងទៀត', 'Replay video')}</button>}
    <GuestSectionNavigation rootRef={rootRef} visible={opened && !mapOpen && !galleryOpen && !playback.active} english={en} sectionKeys={floralSections(vm).join(',')} availableKeys={navigationKeys} />
  </div></InvitationLocaleContext>;
}
