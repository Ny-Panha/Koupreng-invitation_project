import { useTemplateContinuation } from "./useTemplateContinuation";
import { useId, useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { useAuth } from "@/features/auth/hooks/useAuth";
import { useToggle } from "../../shared/hooks/useToggle";
import { useT } from "../../shared/i18n/useT";
import { useLanguageStore } from "../../stores/useLanguageStore";
import authService from "@/features/auth/api/authApi";
import SocialAuthButtons from "./components/SocialAuthButtons";
import AuthLayout from "./components/AuthLayout";
import "./AuthPage.css";

function Login() {
  const emailId = useId();
  const passwordId = useId();
  const errorId = useId();
  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, togglePassword] = useToggle();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { login } = useAuth();
  const { nav, auth } = useT();
  const lang = useLanguageStore((state) => state.lang);
  const isKm = lang === "km";
  const redirectTo = useTemplateContinuation(searchParams);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (loading) return;
    setError("");

    if (!identifier.trim() || !password) {
      setError(auth("requiredFields"));
      return;
    }

    setLoading(true);
    try {
      const authData = await authService.login(identifier.trim(), password);
      login(authData);
      navigate(redirectTo, { replace: true });
    } catch (err) {
      setError(err.message || auth("loginFailed"));
    } finally {
      setLoading(false);
    }
  };

  return (
    <AuthLayout>
      {/* Card */}
      <div className="auth-card">
        {/* Header */}
        <div className="auth-header">
          <h1 className="auth-title">{auth("loginTitle")}</h1>
          <p className="auth-subtitle">{auth("loginSubtitle")}</p>
        </div>

        {error && (
          <p id={errorId} role="alert" className="auth-error">
            {error}
          </p>
        )}

        {/* Form */}
        <form onSubmit={handleSubmit} className="auth-form" aria-busy={loading}>
          {/* Email / Phone */}
          <div className="auth-field">
            <label htmlFor={emailId} className="auth-label">
              {auth("phoneOrEmail")}
            </label>
            <input
              id={emailId}
              type="text"
              value={identifier}
              onChange={(e) => setIdentifier(e.target.value)}
              placeholder={auth("phoneOrEmailPlaceholder")}
              className={`auth-input${error ? " error" : ""}`}
              autoComplete="username"
              required
              autoCapitalize="none"
              spellCheck={false}
              aria-invalid={Boolean(error)}
              aria-describedby={error ? errorId : undefined}
            />
          </div>

          {/* Password */}
          <div className="auth-field">
            <label htmlFor={passwordId} className="auth-label">
              {auth("password")}
            </label>
            <div className="auth-input-wrap">
              <input
                id={passwordId}
                type={showPassword ? "text" : "password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder={auth("passwordPlaceholder")}
                className={`auth-input${error ? " error" : ""}`}
                autoComplete="current-password"
                required
                aria-invalid={Boolean(error)}
                aria-describedby={error ? errorId : undefined}
              />
              <button
                type="button"
                onClick={togglePassword}
                onMouseDown={(e) => e.preventDefault()}
                aria-label={
                  showPassword
                    ? isKm
                      ? "លាក់ពាក្យសម្ងាត់"
                      : "Hide password"
                    : isKm
                    ? "បង្ហាញពាក្យសម្ងាត់"
                    : "Show password"
                }
                aria-pressed={showPassword}
                className="auth-eye-btn"
              >
                {showPassword ? (
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="18"
                    height="18"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                    aria-hidden="true"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59m0 0A9.953 9.953 0 0112 5c4.478 0 8.268 2.943 9.543 7a10.025 10.025 0 01-4.132 5.411m0 0L21 21"
                    />
                  </svg>
                ) : (
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="18"
                    height="18"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                    aria-hidden="true"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"
                    />
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"
                    />
                  </svg>
                )}
              </button>
            </div>
          </div>

          {/* Submit */}
          <button type="submit" className="auth-submit" disabled={loading}>
            {loading ? auth("signingIn") : auth("signIn")}
          </button>
        </form>

        {/* Divider */}
        <p className="auth-divider">{auth("orContinueWith")}</p>

        {/* Social buttons */}
        <SocialAuthButtons redirectTo={redirectTo} />

        {/* Forgot password */}
        <div className="auth-footer">
          <Link
            to={
              redirectTo && redirectTo !== "/app/events"
                ? `/forgot-password?next=${encodeURIComponent(redirectTo)}`
                : "/forgot-password"
            }
            className="auth-footer-link"
          >
            {auth("forgotPassword")}
          </Link>
        </div>

        {/* Register link */}
        <p className="auth-footer-text">
          {auth("noAccount")}{" "}
          <Link to={redirectTo && redirectTo !== "/app/events" ? `/register?next=${encodeURIComponent(redirectTo)}` : "/register"}>
            {nav("register")}
          </Link>
        </p>
      </div>
    </AuthLayout>
  );
}

export default Login;
