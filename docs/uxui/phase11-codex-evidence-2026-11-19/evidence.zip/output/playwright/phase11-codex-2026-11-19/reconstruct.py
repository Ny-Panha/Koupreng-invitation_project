from pathlib import Path
import subprocess,tarfile,io,json,hashlib,shutil
root=Path.cwd();out=root/'output/playwright/phase11-codex-2026-11-19'
paths=['apps/frontend-user/src','apps/frontend-user/package.json','apps/frontend-user/index.html','apps/frontend-user/vite.config.js']
data=subprocess.check_output(['git','archive','HEAD',*paths])
for stage in ['head','gemini']:
    target=out/f'reconstructed-{stage}';target.mkdir(exist_ok=True)
    with tarfile.open(fileobj=io.BytesIO(data)) as archive:
        for member in archive.getmembers():
            resolved=(target/member.name).resolve()
            if not resolved.is_relative_to(target.resolve()):raise RuntimeError('Unsafe archive path')
        archive.extractall(target,filter='data')
    app=target/'apps/frontend-user'
    if stage=='gemini':
        for name in ['EventCreatePage.jsx','EventCreatePage.css']:
            rel=f'apps/frontend-user/src/features/events/onboarding/{name}'
            shutil.copy2(out/'preimages'/rel,target/rel)
    public=[]
    for env in ['.env','.env.local','.env.production','.env.production.local']:
        p=root/env
        if p.exists():
            public.extend(line for line in p.read_text(encoding='utf-8').splitlines() if line.startswith('VITE_'))
    (target/'.env').write_text('\n'.join(public),encoding='utf-8')
    for name in ['node_modules','public']:
        destination=app/name
        if not destination.exists():
            command=f"New-Item -ItemType Junction -Path '{destination}' -Target '{root/'apps/frontend-user'/name}' | Out-Null"
            subprocess.run(['powershell','-NoProfile','-Command',command],check=True)
    manifest=[{'path':str(p.relative_to(target)).replace('\\','/'),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in (app/'src').rglob('*') if p.is_file() and not '.test.' in p.name]
    (out/f'reconstructed-{stage}-sources.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
print('HEAD and Gemini reconstructed in isolated ignored directories; actual checkout untouched.')
