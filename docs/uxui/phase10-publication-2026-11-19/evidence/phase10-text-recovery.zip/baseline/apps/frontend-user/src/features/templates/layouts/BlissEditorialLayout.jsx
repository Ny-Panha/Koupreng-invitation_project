import InvitationLabel from '@/features/templates/shared/InvitationLabel';
import IllustratedMap from '@/features/templates/shared/IllustratedMap';
import SaveTheDate from '../shared/SaveTheDate';
import AuthoredClosing from '../shared/AuthoredClosing';
import InvitationBranding from '../shared/InvitationBranding';
import AuthoredFamilies from '../shared/AuthoredFamilies';
import { authoredHeadingStyle } from '../shared/templateTypography';
import ProgramTimeline from '../shared/ProgramTimeline';
import ProgramDetails from "../shared/ProgramDetails";
import { useState, useRef, useEffect } from "react";
import { Link } from "react-router-dom";
import { X, CheckCircle2 } from "lucide-react";
import FloatingAudioPlayer from "../shared/AudioPlayer/FloatingAudioPlayer";
import defaultMusicUrl from "../../../assets/music/Instrumental Wedding Music (VioSounds Cover).m4a";
import CoverBackground from "../shared/Openings/CoverBackground";
import { isTrustedPreviewMessage, readEmbeddedPreviewChannel } from "@/shared/preview/previewMessaging";
import "./bliss-editorial.css";

export default function BlissEditorialLayout({
  content = {},
  preview = false,
  previewChannel,
  showBack = true,
  backTo = "/templates",
  backLabel = "ត្រឡប់ទៅគំរូទាំងអស់",
  useTemplateLink,
  children,
}) {
  const [liveData, setLiveData] = useState(null);
  const effectiveContent = { ...content, ...liveData };

  useEffect(() => {
    const channel = previewChannel || readEmbeddedPreviewChannel();
    if (!channel) return undefined;
    const handleMessage = (e) => {
      if (!isTrustedPreviewMessage(e, channel)) return;
      if (e.data?.type === "LIVE_PREVIEW_SYNC" && e.data.data) {
        setLiveData(e.data.data);
      }
    };
    window.addEventListener("message", handleMessage);
    return () => window.removeEventListener("message", handleMessage);
  }, [previewChannel]);

  const groom = effectiveContent.groom || "";
  const bride = effectiveContent.bride || "";
  const groomEn = effectiveContent.groomEn || "";
  const brideEn = effectiveContent.brideEn || "";
  const dateText = effectiveContent.dateText || "";
  const dateTextEn = effectiveContent.dateTextEn || "";
  const venue = effectiveContent.venue || {
    name: "",
    hall: "",
    address: "",
  };
  const coverImage = effectiveContent.coverImage || "/images/wedding/couple-hero-meadow.webp";
  const musicUrl = effectiveContent.music?.url || effectiveContent.music || defaultMusicUrl;

  // RSVP Drawer state
  const [drawerOpen, setDrawerOpen] = useState(false);
  const drawer = useRef(null);
  useEffect(() => {
    if (!drawerOpen) return;
    const previous = document.activeElement, panel = drawer.current;
    panel?.querySelector('button')?.focus();
    const keydown = event => {
      if (event.key === 'Escape') { event.preventDefault(); setDrawerOpen(false); }
      if (event.key !== 'Tab') return;
      const controls = [...panel.querySelectorAll('button, input, select, textarea, a[href]')].filter(node => !node.disabled && node.getClientRects().length);
      const first = controls[0], last = controls.at(-1);
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); }
    };
    panel?.addEventListener('keydown', keydown);
    return () => { panel?.removeEventListener('keydown', keydown); if (previous?.isConnected) previous.focus({ preventScroll: true }); };
  }, [drawerOpen]);
  const [rsvpState, setRsvpState] = useState({
    name: "",
    attending: "yes",
    guests: "1",
    note: "",
    submitted: false,
  });

  const handleRsvpSubmit = (e) => {
    e.preventDefault();
    setRsvpState((prev) => ({ ...prev, submitted: true }));
  };

  const defaultGallery = [
    "/images/wedding/couple-hero-meadow.webp",
    "/images/wedding/couple-celebration-confetti.webp",
    "/images/wedding/couple-studio-bow.webp",
    "/images/wedding/couple-garden-rings.webp",
  ];

  const galleryImages = (effectiveContent.gallery && effectiveContent.gallery.length)
    ? effectiveContent.gallery.map(img => typeof img === "string" ? img : img.src || img.url)
    : defaultGallery;

  const isEnabled = (key) => content.enabledSections?.[key] !== false;
  const dressColors = Array.isArray(content.dressCode)
    ? content.dressCode
    : (Array.isArray(content.dressCode?.colors) ? content.dressCode.colors : (content.dressColors || [
        { hex: "#2C2C2C", name: "Charcoal" },
        { hex: "#8E8279", name: "Taupe" },
        { hex: "#D6CFC7", name: "Cream" },
        { hex: "#FFFFFF", name: "White" },
      ]));
  const faqList = Array.isArray(content.faq) && content.faq.length > 0 ? content.faq : [
    { id: "f1", q: "តើមានចំណតរថយន្តដែរឬទេ?", a: "បាទ/ចាស មានចំណតរថយន្តធំទូលាយដោយឥតគិតថ្លៃសម្រាប់ភ្ញៀវកិត្តិយសទាំងអស់។" },
    { id: "f2", q: "តើអាចនាំកុមារតូចៗមកបានទេ?", a: "យើងខ្ញុំស្វាគមន៍វត្តមានកុមារតូចៗទាំងអស់ក្នុងពិធីមង្គលការ។" },
    { id: "f3", q: "តើកម្មវិធីចាប់ផ្ដើម និងបញ្ចប់នៅម៉ោងប៉ុន្មាន?", a: "កម្មវិធីទទួលភ្ញៀវចាប់ផ្ដើមពីម៉ោង ០៥:០០ ល្ងាច តទៅ។" },
  ];

  return (
    <div className="bliss-container">
      <FloatingAudioPlayer src={musicUrl} />

      {/* Editorial Minimalist Header */}
      <header className="bliss-header">
        <div className="bliss-monogram">
          {groomEn.charAt(0)} &amp; {brideEn.charAt(0)}
        </div>
        <nav className="bliss-header-nav">
          <a href="#editorial-hero" className="bliss-header-link"><InvitationLabel value={"សេចក្តីផ្តើម"} /></a>
          {isEnabled("schedule") && <a href="#editorial-program" className="bliss-header-link"><InvitationLabel value={"កម្មវិធី"} /></a>}
          {isEnabled("gallery") && <a href="#editorial-spread" className="bliss-header-link"><InvitationLabel value={"កម្រងរូបភាព"} /></a>}
          {isEnabled("dressCode") && <a href="#editorial-dress" className="bliss-header-link">Dress Code</a>}
          {isEnabled("map") && <a href="#editorial-venue" className="bliss-header-link"><InvitationLabel value={"ទីតាំង"} /></a>}
          {isEnabled("faq") && <a href="#editorial-faq" className="bliss-header-link">FAQ</a>}
          {isEnabled("rsvp") && (
            <button type="button" className="bliss-rsvp-trigger" onClick={() => setDrawerOpen(true)}>
              RSVP
            </button>
          )}
          {showBack && (
            <Link to={backTo} className="bliss-header-link" style={{ opacity: 0.7 }}>
              ← {backLabel}
            </Link>
          )}
        </nav>
      </header>

      {/* Split-Screen Hero */}
      <section id="editorial-hero" className="bliss-hero-split">
        <div className="bliss-hero-visual">
          <CoverBackground
            content={effectiveContent}
            templateDefault={{
              src: coverImage,
              type: "image",
              poster: coverImage,
            }}
          />
        </div>
        <div className="bliss-hero-editorial">
          <span className="bliss-issue-tag">{effectiveContent.title || 'THE WEDDING CELEBRATION'}</span>
          {effectiveContent.subtitle && <p>{effectiveContent.subtitle}</p>}
          <h1 className="bliss-editorial-names" style={authoredHeadingStyle(effectiveContent, groom + bride)}>
            {groom} &amp;<br />
            {bride}
          </h1>
          <p className="bliss-editorial-date">{dateText}</p>
          <AuthoredFamilies content={effectiveContent} />
          <blockquote className="bliss-quote">
            {effectiveContent.messageTitle && <p>{effectiveContent.messageTitle}</p>}
            {effectiveContent.message || 'សេចក្តីស្រឡាញ់ពិតមិនមែនជាការសម្លឹងមើលមុខគ្នានោះទេ ប៉ុន្តែជាការសម្លឹងទៅកាន់ទិសដៅតែមួយរួមគ្នាជាមួយមនុស្សជាទីស្រឡាញ់។'}
          </blockquote>
          {isEnabled("rsvp") && (
            <div>
              <button type="button" className="bliss-rsvp-trigger" onClick={() => setDrawerOpen(true)}><InvitationLabel value={"សូមបញ្ជាក់ការចូលរួម • RSVP NOW"} /></button>
            </div>
          )}
        </div>
      </section>

      {/* Editorial Program Section */}
      {isEnabled("countdown") && <section className="bliss-section"><SaveTheDate content={effectiveContent} /></section>}
      {isEnabled("schedule") && (
        <section id="editorial-program" className="bliss-section">
          <div className="bliss-section-heading">
            <p className="bliss-kicker">Order of Events</p>
            <h2 className="bliss-title"><InvitationLabel value={"កាលវិភាគពិធីមង្គលការ"} /></h2>
          </div>

          {(effectiveContent.programDays || effectiveContent.invitationStyleV1?.program) ? <ProgramTimeline content={effectiveContent} /> : <div className="bliss-program-list">{(effectiveContent.schedule || []).map((item, i) => <article className="bliss-program-row" key={item.id || i}><div className="bliss-program-time">{item.time}<ProgramDetails item={item} content={effectiveContent} /></div><div><h3 className="bliss-program-title">{item.title}</h3><p className="bliss-program-desc">{item.description}</p></div></article>)}</div>}
        </section>
      )}

      {/* Dress Code Section */}
      {isEnabled("dressCode") && dressColors.length > 0 && (
        <section id="editorial-dress" className="bliss-section" style={{ textAlign: "center", borderTop: "1px solid var(--bliss-border)" }}>
          <p className="bliss-kicker">Palette &amp; Attire</p>
          <h2 className="bliss-title" style={{ marginBottom: "1.5rem" }}>{content.dressCode?.name || "ពណ៌សម្លៀកបំពាក់ (Dress Code)"}</h2>
          <div style={{ display: "flex", justifyContent: "center", alignItems: "center", gap: "1.5rem", flexWrap: "wrap", maxWidth: "600px", margin: "0 auto" }}>
            {dressColors.map((c, i) => (
              <div key={i} style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: "6px" }}>
                <span
                  style={{
                    width: "42px",
                    height: "42px",
                    borderRadius: "50%",
                    backgroundColor: c.hex,
                    border: "1px solid var(--bliss-border)",
                    boxShadow: "0 2px 8px rgba(0,0,0,0.08)",
                  }}
                />
                <span style={{ fontSize: "0.8rem", letterSpacing: "normal", color: "var(--bliss-charcoal)", textTransform: "uppercase" }}>{c.name}</span>
              </div>
            ))}
          </div>
          {content.dressCode?.description && (
            <p style={{ color: "var(--bliss-taupe)", maxWidth: "500px", margin: "1.5rem auto 0", lineHeight: "1.7", fontSize: "0.85rem" }}>
              {content.dressCode.description}
            </p>
          )}
        </section>
      )}

      {/* Asymmetrical Gallery Spread */}
      {isEnabled("gallery") && (
        <section id="editorial-spread" className="bliss-section" style={{ borderTop: "1px solid var(--bliss-border)" }}>
          <div className="bliss-section-heading">
            <p className="bliss-kicker">Visual Editorial</p>
            <h2 className="bliss-title"><InvitationLabel value={"កម្រងអនុស្សាវរីយ៍"} /></h2>
          </div>

          <div className="bliss-gallery-spread">
            <div className="bliss-gallery-col-1 bliss-gallery-frame">
              <img src={galleryImages[0]} alt="Spread 1" loading="lazy" />
            </div>
            <div className="bliss-gallery-col-2 bliss-gallery-frame">
              <img src={galleryImages[1]} alt="Spread 2" loading="lazy" />
            </div>
            <div className="bliss-gallery-col-3 bliss-gallery-frame">
              <img src={galleryImages[2]} alt="Spread 3" loading="lazy" />
            </div>
            <div className="bliss-gallery-col-4 bliss-gallery-frame">
              <img src={galleryImages[3]} alt="Spread 4" loading="lazy" />
            </div>
          </div>
        </section>
      )}

      {/* Venue Information */}
      {isEnabled("map") && (
        <section id="editorial-venue" className="bliss-section" style={{ textAlign: "center", borderTop: "1px solid var(--bliss-border)" }}>
          <IllustratedMap content={effectiveContent} />
          <p className="bliss-kicker">The Destination</p>
          <h2 className="bliss-title" style={{ marginBottom: "1rem" }}>{venue.name}</h2>
          <p style={{ color: "var(--bliss-taupe)", maxWidth: "500px", margin: "0 auto 2rem", lineHeight: "1.7" }}>
            {venue.address}
          </p>
          <a
            href={`https://maps.google.com/?q=${encodeURIComponent(venue.name + " " + venue.address)}`}
            target="_blank"
            rel="noopener noreferrer"
            style={{
              display: "inline-block",
              fontSize: "0.8rem",
              letterSpacing: "0.2em",
              textTransform: "uppercase",
              color: "var(--bliss-charcoal)",
              borderBottom: "1px solid var(--bliss-charcoal)",
              paddingBottom: "4px",
              textDecoration: "none",
            }}
          >
            View on Google Maps →
          </a>
        </section>
      )}

      {/* FAQ Section */}
      {isEnabled("faq") && faqList.length > 0 && (
        <section id="editorial-faq" className="bliss-section" style={{ borderTop: "1px solid var(--bliss-border)" }}>
          <div className="bliss-section-heading">
            <p className="bliss-kicker">Q &amp; A</p>
            <h2 className="bliss-title"><InvitationLabel value={"សំណួរដែលសួរញឹកញាប់"} /></h2>
          </div>
          <div style={{ maxWidth: "650px", margin: "0 auto", display: "flex", flexDirection: "column", gap: "1rem" }}>
            {faqList.map((item) => (
              <details
                key={item.id || item.q}
                style={{
                  borderBottom: "1px solid var(--bliss-border)",
                  paddingBottom: "1rem",
                }}
              >
                <summary style={{ fontWeight: "600", color: "var(--bliss-charcoal)", cursor: "pointer", fontSize: "0.95rem" }}>
                  {item.q}
                </summary>
                <p style={{ marginTop: "0.75rem", fontSize: "0.85rem", color: "var(--bliss-taupe)", lineHeight: "1.7" }}>
                  {item.a}
                </p>
              </details>
            ))}
          </div>
        </section>
      )}

      {/* Footer */}
      <footer style={{ padding: "4rem 2rem", textAlign: "center", borderTop: "1px solid var(--bliss-border)" }}>
        <AuthoredClosing content={effectiveContent} />
        <p style={{ fontFamily: "Cinzel, serif", fontSize: "1.4rem", letterSpacing: "0.15em", marginBottom: "0.5rem" }}>
          {groomEn} &amp; {brideEn}
        </p>
        <p style={{ fontSize: "0.8rem", color: "var(--bliss-taupe)", letterSpacing: "0.2em", textTransform: "uppercase", marginBottom: "2rem" }}>
          Phnom Penh, Cambodia • {dateTextEn}
        </p>
        {!preview && useTemplateLink && (
          <Link
            to={useTemplateLink}
            style={{
              display: "inline-block",
              background: "var(--bliss-charcoal)",
              color: "#ffffff",
              padding: "0.8rem 2rem",
              fontSize: "0.85rem",
              letterSpacing: "normal",
              textTransform: "uppercase",
              textDecoration: "none",
            }}
          >
            ប្រើគំរូ Bliss Editorial នេះ
          </Link>
        )}
        <InvitationBranding content={effectiveContent} />
      </footer>

      {/* Slide-out RSVP Drawer */}
      <div
        className={`bliss-drawer-backdrop ${drawerOpen ? "open" : ""}`}
        onClick={() => setDrawerOpen(false)}
      />
      <div ref={drawer} className={`bliss-drawer ${drawerOpen ? "open" : ""}`} role="dialog" aria-label="RSVP" aria-modal={drawerOpen || undefined} inert={!drawerOpen}>
        <button type="button" className="bliss-drawer-close" aria-label={String(effectiveContent.languageMode).toLowerCase() === 'en' ? 'Close RSVP' : 'បិទ RSVP'} onClick={() => setDrawerOpen(false)}>
          <X className="w-6 h-6" />
        </button>
        <h2 className="bliss-drawer-title">RSVP</h2>
        <p style={{ color: "var(--bliss-taupe)", fontSize: "0.9rem", marginBottom: "2rem" }}><InvitationLabel value={"សូមបញ្ជាក់ការចូលរួមរបស់លោកអ្នក"} /></p>

        {children || (rsvpState.submitted ? (
          <div style={{ textAlign: "center", padding: "3rem 1rem" }}>
            <CheckCircle2 className="w-14 h-14 text-stone-800 mx-auto mb-4" />
            <h3 style={{ fontSize: "1.2rem", fontWeight: "600", marginBottom: "0.5rem" }}><InvitationLabel value={"សូមអរគុណសម្រាប់ការឆ្លើយតប!"} /></h3>
            <p style={{ color: "var(--bliss-taupe)", fontSize: "0.9rem" }}>
              យើងខ្ញុំទន្ទឹងរង់ចាំទទួលស្វាគមន៍លោកអ្នកក្នុងថ្ងៃមង្គលការ។
            </p>
          </div>
        ) : (
          <form onSubmit={handleRsvpSubmit}>
            <div style={{ marginBottom: "1.5rem" }}>
              <label style={{ display: "block", fontSize: "0.8rem", letterSpacing: "normal", textTransform: "uppercase", marginBottom: "0.5rem" }}><InvitationLabel value={"ឈ្មោះពេញ (Full Name)"} /></label>
              <input
                type="text"
                required
                style={{ width: "100%", padding: "0.75rem", border: "1px solid var(--bliss-border)", background: "var(--bliss-bg)" }}
                value={rsvpState.name}
                onChange={(e) => setRsvpState({ ...rsvpState, name: e.target.value })}
              />
            </div>

            <div style={{ marginBottom: "1.5rem" }}>
              <label style={{ display: "block", fontSize: "0.8rem", letterSpacing: "normal", textTransform: "uppercase", marginBottom: "0.5rem" }}><InvitationLabel value={"ការចូលរួម (Attendance)"} /></label>
              <div style={{ display: "flex", gap: "1rem" }}>
                <label style={{ display: "flex", alignItems: "center", gap: "0.5rem", fontSize: "0.9rem" }}>
                  <input
                    type="radio"
                    name="bliss-attending"
                    value="yes"
                    checked={rsvpState.attending === "yes"}
                    onChange={(e) => setRsvpState({ ...rsvpState, attending: e.target.value })}
                  /><InvitationLabel value={"ចូលរួម (Yes)"} /></label>
                <label style={{ display: "flex", alignItems: "center", gap: "0.5rem", fontSize: "0.9rem" }}>
                  <input
                    type="radio"
                    name="bliss-attending"
                    value="no"
                    checked={rsvpState.attending === "no"}
                    onChange={(e) => setRsvpState({ ...rsvpState, attending: e.target.value })}
                  /><InvitationLabel value={"មិនអាចចូលរួម (No)"} /></label>
              </div>
            </div>

            <div style={{ marginBottom: "2rem" }}>
              <label style={{ display: "block", fontSize: "0.8rem", letterSpacing: "normal", textTransform: "uppercase", marginBottom: "0.5rem" }}><InvitationLabel value={"ពាក្យជូនពរ (Blessing Note)"} /></label>
              <textarea
                rows="4"
                style={{ width: "100%", padding: "0.75rem", border: "1px solid var(--bliss-border)", background: "var(--bliss-bg)" }}
                placeholder="សរសេរពាក្យជូនពរ..."
                value={rsvpState.note}
                onChange={(e) => setRsvpState({ ...rsvpState, note: e.target.value })}
              />
            </div>

            <button
              type="submit"
              style={{
                width: "100%",
                background: "var(--bliss-charcoal)",
                color: "#ffffff",
                padding: "0.9rem",
                border: "none",
                fontSize: "0.85rem",
                letterSpacing: "normal",
                textTransform: "uppercase",
                cursor: "pointer",
              }}
            ><InvitationLabel value={"ផ្ញើការឆ្លើយតប • SUBMIT"} /></button>
          </form>
        ))}
      </div>
    </div>
  );
}
