from pathlib import Path
import subprocess,json,hashlib
root=Path.cwd();target=root/'output/playwright/phase11-codex-2026-11-19/historical';target.mkdir(exist_ok=True)
records=[]
for name in ['phase11-baseline.spec.js','phase11-matrix.spec.js','phase11-bilingual.spec.js','phase11-features.spec.js']:
    original=root/'apps/frontend-user/tests/e2e'/name
    data=original.read_text(encoding='utf-8').replace('../../docs/phase11/evidence','../../output/playwright/phase11-codex-2026-11-19/historical-captures')
    p=target/name;p.write_text(data,encoding='utf-8')
    records.append({'original':str(original.relative_to(root)).replace('\\','/'),'originalSha256':hashlib.sha256(original.read_bytes()).hexdigest(),'copySha256':hashlib.sha256(p.read_bytes()).hexdigest(),'onlyAdaptation':'Screenshot destination redirected to ignored evidence; assertions unchanged'})
for name,source in [('support',root/'apps/frontend-user/tests/e2e/support'),('node_modules',root/'apps/frontend-user/node_modules')]:
    p=target/name
    if not p.exists():subprocess.run(['powershell','-NoProfile','-Command',f"New-Item -ItemType Junction -Path '{p}' -Target '{source}' | Out-Null"],check=True)
(target/'package.json').write_text('{"type":"module"}',encoding='utf-8')
(target.parent/'historical-adaptations.json').write_text(json.dumps(records,indent=2),encoding='utf-8')
print('Four historical specs copied with isolated screenshot destinations; original files unchanged.')
